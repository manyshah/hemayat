import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

const String kInitialUrl = 'https://hemayat.sfara.ir/';
const String kAppName = 'سامانه‌یار حمایت';
const Color kPrimaryColor = Color(0xFF0F1720);
const Color kBlueColor = Color(0xFF357DEE);
const Color kPageColor = Color(0xFFF7F7F7);

enum AppStage { phone, otp, web }

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: kPageColor,
      statusBarIconBrightness: Brightness.dark,
      systemNavigationBarColor: Colors.white,
      systemNavigationBarIconBrightness: Brightness.dark,
    ),
  );
  runApp(const HemayatWebApp());
}

class HemayatWebApp extends StatelessWidget {
  const HemayatWebApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: kAppName,
      debugShowCheckedModeBanner: false,
      locale: const Locale('fa', 'IR'),
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Roboto',
        scaffoldBackgroundColor: kPageColor,
        colorScheme: ColorScheme.fromSeed(
          seedColor: kBlueColor,
          primary: kBlueColor,
          secondary: const Color(0xFF16A34A),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: Color(0xFFE1E5EA)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: Color(0xFFE1E5EA)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: kBlueColor, width: 1.2),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: Color(0xFFEF4444)),
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
      ),
      builder: (context, child) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: const HemayatShell(),
    );
  }
}

class HemayatShell extends StatefulWidget {
  const HemayatShell({super.key});

  @override
  State<HemayatShell> createState() => _HemayatShellState();
}

class _HemayatShellState extends State<HemayatShell> {
  late final WebViewController _webController;
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _otpController = TextEditingController();

  AppStage _stage = AppStage.phone;
  int _progress = 0;
  bool _hasMainFrameError = false;
  bool _submittingPhone = false;
  bool _submittingOtp = false;
  bool _webPrepared = false;
  String _errorText = 'صفحه باز نشد. اینترنت را بررسی کنید و دوباره تلاش کنید.';
  String? _submittedPhone;
  String? _message;
  Timer? _timer;
  int _resendSeconds = 0;

  @override
  void initState() {
    super.initState();
    _webController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.white)
      ..enableZoom(false)
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (progress) {
            if (!mounted) return;
            setState(() => _progress = progress);
          },
          onPageStarted: (_) {
            if (!mounted) return;
            setState(() {
              _hasMainFrameError = false;
              _progress = 0;
            });
          },
          onPageFinished: (_) {
            if (!mounted) return;
            setState(() {
              _webPrepared = true;
              _progress = 100;
            });
          },
          onWebResourceError: (error) {
            if (!mounted || error.isForMainFrame != true) return;
            setState(() {
              _hasMainFrameError = true;
              _errorText = error.description.isNotEmpty
                  ? error.description
                  : 'اتصال برقرار نشد.';
            });
          },
          onNavigationRequest: (request) {
            final uri = Uri.tryParse(request.url);
            if (uri == null) return NavigationDecision.navigate;
            if (<String>{'tel', 'mailto', 'sms', 'intent', 'market'}.contains(uri.scheme)) {
              unawaited(_openExternal(uri));
              return NavigationDecision.prevent;
            }
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadRequest(Uri.parse(kInitialUrl));
  }

  @override
  void dispose() {
    _timer?.cancel();
    _phoneController.dispose();
    _otpController.dispose();
    super.dispose();
  }

  Future<void> _openExternal(Uri uri) async {
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      _showSnack('امکان باز کردن این لینک وجود ندارد.');
    }
  }

  String _normalizePhone(String input) {
    final english = input
        .replaceAll('۰', '0')
        .replaceAll('۱', '1')
        .replaceAll('۲', '2')
        .replaceAll('۳', '3')
        .replaceAll('۴', '4')
        .replaceAll('۵', '5')
        .replaceAll('۶', '6')
        .replaceAll('۷', '7')
        .replaceAll('۸', '8')
        .replaceAll('۹', '9')
        .replaceAll('٠', '0')
        .replaceAll('١', '1')
        .replaceAll('٢', '2')
        .replaceAll('٣', '3')
        .replaceAll('٤', '4')
        .replaceAll('٥', '5')
        .replaceAll('٦', '6')
        .replaceAll('٧', '7')
        .replaceAll('٨', '8')
        .replaceAll('٩', '9');
    return english.replaceAll(RegExp(r'\D'), '');
  }

  bool _isValidPhone(String phone) => RegExp(r'^09\d{9}$').hasMatch(phone);

  void _startResendTimer() {
    _timer?.cancel();
    setState(() => _resendSeconds = 60);
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      if (_resendSeconds <= 1) {
        timer.cancel();
        setState(() => _resendSeconds = 0);
      } else {
        setState(() => _resendSeconds -= 1);
      }
    });
  }

  Future<void> _submitPhone() async {
    if (_submittingPhone) return;

    final phone = _normalizePhone(_phoneController.text);
    if (!_isValidPhone(phone)) {
      setState(() => _message = 'شماره موبایل را به صورت ۱۱ رقمی و با 09 وارد کنید.');
      return;
    }

    setState(() {
      _submittingPhone = true;
      _message = 'در حال ارسال کد تأیید...';
      _submittedPhone = phone;
      _hasMainFrameError = false;
    });

    final startedAt = DateTime.now();

    try {
      await _webController.loadRequest(Uri.parse(kInitialUrl));

      // First submit the real phone form inside the government site. The OTP
      // screen is shown only after the hidden WebView really reaches the OTP step.
      final submitted = await _retryJavaScript(
        () => _injectPhone(phone),
        attempts: 14,
        delay: const Duration(milliseconds: 650),
      );

      // In practice the SMS may be sent even when the government site does not
      // expose a detectable OTP DOM state to WebView. So after a real phone
      // submit, treat it as successful unless the page clearly shows an invalid
      // phone-number error. The OTP screen still protects against injecting the
      // code into a phone field.
      await Future<void>.delayed(const Duration(milliseconds: 900));
      final invalidPhone = await _hasInvalidPhoneError();

      final remaining = const Duration(seconds: 5) - DateTime.now().difference(startedAt);
      if (remaining > Duration.zero) {
        await Future<void>.delayed(remaining);
      }

      if (!mounted) return;

      if (submitted && !invalidPhone) {
        setState(() {
          _submittingPhone = false;
          _stage = AppStage.otp;
          _message = null;
        });
        _startResendTimer();
      } else {
        setState(() {
          _submittingPhone = false;
          _stage = AppStage.phone;
          _message = invalidPhone
              ? 'شماره موبایل معتبر نیست؛ لطفاً شماره را بررسی کنید.'
              : 'ارسال کد انجام نشد؛ لطفاً دوباره تلاش کنید.';
        });
      }
    } catch (_) {
      final remaining = const Duration(seconds: 5) - DateTime.now().difference(startedAt);
      if (remaining > Duration.zero) {
        await Future<void>.delayed(remaining);
      }
      if (!mounted) return;
      setState(() {
        _submittingPhone = false;
        _stage = AppStage.phone;
        _message = 'ارسال کد انجام نشد؛ اتصال را بررسی کنید و دوباره تلاش کنید.';
      });
    }
  }

  Future<void> _submitOtp() async {
    final code = _normalizePhone(_otpController.text);
    if (code.length < 4) {
      setState(() => _message = 'کد تأیید را کامل وارد کنید.');
      return;
    }

    setState(() {
      _submittingOtp = true;
      _message = 'در حال جایگذاری کد تأیید...';
      _hasMainFrameError = false;
    });

    try {
      final ready = await _waitForOtpStep();
      if (!ready) {
        // Fallback: the SMS was sent, but the WebView DOM did not expose the OTP field.
        // Do not inject the code into the phone field. Show the official site inside the app
        // so the user can enter the received code directly and continue without getting stuck.
        if (!mounted) return;
        setState(() {
          _submittingOtp = false;
          _stage = AppStage.web;
          _message = 'فرم رسمی سامانه باز شد؛ کد تأیید را مستقیم در همین صفحه وارد کنید.';
        });
        _setWebSystemUi();
        return;
      }

      final ok = await _retryJavaScript(
        () => _injectOtp(code),
        attempts: 14,
        delay: const Duration(milliseconds: 550),
      );

      if (!mounted) return;

      if (ok) {
        setState(() {
          _submittingOtp = false;
          _stage = AppStage.web;
          _message = null;
        });
        _setWebSystemUi();
      } else {
        setState(() {
          _submittingOtp = false;
          _stage = AppStage.web;
          _message = 'فرم رسمی سامانه باز شد؛ کد تأیید را مستقیم در همین صفحه وارد کنید.';
        });
        _setWebSystemUi();
      }
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _submittingOtp = false;
        _stage = AppStage.web;
        _message = 'فرم رسمی سامانه باز شد؛ کد تأیید را مستقیم در همین صفحه وارد کنید.';
      });
      _setWebSystemUi();
    }
  }

  Future<bool> _retryJavaScript(
    Future<bool> Function() action, {
    required int attempts,
    required Duration delay,
  }) async {
    for (var i = 0; i < attempts; i++) {
      await Future.delayed(i == 0 && _webPrepared ? Duration.zero : delay);
      try {
        if (await action()) return true;
      } catch (_) {
        // Try again. Some government pages need a little more time after load.
      }
    }
    return false;
  }

  Future<bool> _waitForOtpStep() async {
    for (var i = 0; i < 14; i++) {
      await Future.delayed(const Duration(milliseconds: 650));
      try {
        if (await _isOtpStepReady()) return true;
      } catch (_) {
        // Keep waiting while the page is changing.
      }
    }
    return false;
  }

  Future<bool> _hasInvalidPhoneError() async {
    const script = r'''
(function() {
  const norm = function(s) { return (s || '').replace(/\s+/g, ''); };
  const body = norm(document.body ? document.body.innerText : '');
  if (!body) return 'no_text';
  if (/شماره(موبایل|تلفن)?معتبرنیست|موبایلنامعتبر|شمارهراصحیحواردکنید|شمارهتلفنهمراهمعتبرنمیباشد|شمارههمراهمعتبرنیست|invalidmobile|invalidphone|wrongphone/.test(body)) {
    return 'invalid_phone';
  }
  return 'ok';
})();
''';
    try {
      final result = await _webController.runJavaScriptReturningResult(script);
      return result.toString().contains('invalid_phone');
    } catch (_) {
      return false;
    }
  }

  Future<bool> _isOtpStepReady() async {
    const script = r'''
(function() {
  const norm = function(s) { return (s || '').replace(/\s+/g, ''); };
  const visible = function(el) {
    if (!el) return false;
    const st = window.getComputedStyle(el);
    const r = el.getBoundingClientRect();
    return st.display !== 'none' && st.visibility !== 'hidden' && r.width > 0 && r.height > 0;
  };
  const inputs = Array.from(document.querySelectorAll('input')).filter(visible);
  const body = norm(document.body ? document.body.innerText : '');
  const otpInput = inputs.find(function(i) {
    const text = norm([i.name, i.id, i.placeholder, i.getAttribute('aria-label'), i.type].join(' '));
    const max = Number(i.getAttribute('maxlength') || i.maxLength || 0);
    const looksOtp = /otp|code|verify|verification|کدتایید|کدتأیید|رمزیکبارمصرف/.test(text) || (max >= 4 && max <= 8 && !/09|موبایل|تلفن|شماره/.test(text));
    return looksOtp;
  });
  if (otpInput) return 'otp';
  if (/ارسالمجدد|ویرایش|کدتاییدارسالشده|کدتأییدارسالشده|مرحلهبعد/.test(body)) return 'otp';
  return 'not_otp';
})();
''';
    final result = await _webController.runJavaScriptReturningResult(script);
    return result.toString().contains('otp') && !result.toString().contains('not_otp');
  }

  Future<String> _readVisiblePageText() async {
    const script = r'''
(function() {
  const text = document.body ? document.body.innerText : '';
  return text.replace(/\s+/g, ' ').slice(0, 1500);
})();
''';
    try {
      return (await _webController.runJavaScriptReturningResult(script)).toString();
    } catch (_) {
      return '';
    }
  }

  Future<bool> _injectPhone(String phone) async {
    final script = '''
(function() {
  const phone = ${jsonEncode(phone)};
  const norm = function(s) { return (s || '').replace(/\s+/g, '').replace(/[۰-۹]/g, function(d) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d); }).replace(/[٠-٩]/g, function(d) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); }); };
  const visible = function(el) {
    if (!el) return false;
    const st = window.getComputedStyle(el);
    const r = el.getBoundingClientRect();
    return st.display !== 'none' && st.visibility !== 'hidden' && r.width > 0 && r.height > 0;
  };
  const nativeSet = function(el, value) {
    const proto = el instanceof HTMLTextAreaElement ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    if (desc && desc.set) desc.set.call(el, value); else el.value = value;
  };
  const fire = function(el) {
    ['focus','keydown','keypress','input','keyup','change','blur'].forEach(function(name) {
      try {
        let ev;
        if (name === 'input') ev = new InputEvent('input', { bubbles: true, inputType: 'insertText', data: phone });
        else if (name === 'keydown' || name === 'keyup' || name === 'keypress') ev = new KeyboardEvent(name, { bubbles: true, key: '0' });
        else ev = new Event(name, { bubbles: true });
        el.dispatchEvent(ev);
      } catch (_) {
        el.dispatchEvent(new Event(name, { bubbles: true }));
      }
    });
    if (typeof el.oninput === 'function') { try { el.oninput(); } catch (_) {} }
    if (typeof el.onchange === 'function') { try { el.onchange(); } catch (_) {} }
  };
  const clickReal = function(el) {
    if (!el) return false;
    try { el.scrollIntoView({block:'center', inline:'center'}); } catch (_) {}
    ['pointerdown','mousedown','touchstart','pointerup','mouseup','touchend','click'].forEach(function(name) {
      try { el.dispatchEvent(new MouseEvent(name, { bubbles: true, cancelable: true, view: window })); } catch (_) {}
    });
    try { el.click(); } catch (_) {}
    return true;
  };

  const inputs = Array.from(document.querySelectorAll('input,textarea')).filter(visible);
  const phoneInputs = inputs.filter(function(i) {
    const t = norm([i.name, i.id, i.placeholder, i.getAttribute('aria-label'), i.autocomplete, i.type, i.inputMode].join(' '));
    const max = Number(i.getAttribute('maxlength') || i.maxLength || 0);
    const v = norm(i.value || '');
    const isOtpText = /otp|code|verify|verification|کدتایید|کدتأیید|رمزیکبارمصرف/.test(t) || (max >= 4 && max <= 8 && max !== 11);
    const isPhoneText = /mobile|phone|cell|شماره|موبایل|تلفن/.test(t) || i.type === 'tel' || max === 11 || v.startsWith('09');
    return isPhoneText && !isOtpText;
  });
  let input = phoneInputs[0];
  if (!input) input = inputs.find(function(i) { return (i.type || 'text') !== 'hidden'; });
  if (!input) return 'no_phone_input';

  input.removeAttribute('readonly');
  input.removeAttribute('disabled');
  input.focus();
  nativeSet(input, phone);
  fire(input);

  const current = (input.value || '').replace(/\D/g, '');
  if (current !== phone) return 'phone_not_set';

  const all = Array.from(document.querySelectorAll('button,input[type=button],input[type=submit],a,[role=button]')).filter(visible);
  const enabled = all.filter(function(b) {
    return !b.disabled && b.getAttribute('aria-disabled') !== 'true' && !/disabled/.test(b.className || '');
  });
  let btn = enabled.find(function(b) {
    const t = norm([b.innerText, b.textContent, b.value, b.title, b.getAttribute('aria-label')].join(' '));
    return /ادامه|ارسالکدتایید|ارسالکدتأیید|ارسالکد|تایید|تأیید|ورود|بعدی/.test(t);
  });
  if (!btn) btn = enabled.find(function(b) {
    const t = norm([b.innerText, b.textContent, b.value, b.title, b.getAttribute('aria-label')].join(' '));
    return !/ویرایش|بازگشت|لغو|پشتیبانی|کالابرگ/.test(t);
  });

  if (btn) {
    clickReal(btn);
    return 'clicked_phone_submit';
  }

  if (input.form) {
    try { if (input.form.requestSubmit) input.form.requestSubmit(); else input.form.submit(); return 'submitted_phone_form'; } catch (_) {}
  }
  return 'filled_phone_only';
})();
''';
    final result = await _webController.runJavaScriptReturningResult(script);
    final text = result.toString();
    return text.contains('clicked_phone_submit') || text.contains('submitted_phone_form');
  }

  Future<bool> _injectOtp(String code) async {
    final script = '''
(function() {
  const code = ${jsonEncode(code)};
  const norm = function(s) { return (s || '').replace(/\s+/g, ''); };
  const visible = function(el) {
    if (!el) return false;
    const st = window.getComputedStyle(el);
    const r = el.getBoundingClientRect();
    return st.display !== 'none' && st.visibility !== 'hidden' && r.width > 0 && r.height > 0;
  };
  const nativeSet = function(el, value) {
    const proto = el instanceof HTMLTextAreaElement ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    if (desc && desc.set) desc.set.call(el, value); else el.value = value;
  };
  const fire = function(el) {
    ['focus','keydown','keypress','input','keyup','change','blur'].forEach(function(name) {
      try {
        let ev;
        if (name === 'input') ev = new InputEvent('input', { bubbles: true, inputType: 'insertText', data: code });
        else if (name === 'keydown' || name === 'keyup' || name === 'keypress') ev = new KeyboardEvent(name, { bubbles: true, key: '0' });
        else ev = new Event(name, { bubbles: true });
        el.dispatchEvent(ev);
      } catch (_) {
        el.dispatchEvent(new Event(name, { bubbles: true }));
      }
    });
    if (typeof el.oninput === 'function') { try { el.oninput(); } catch (_) {} }
    if (typeof el.onchange === 'function') { try { el.onchange(); } catch (_) {} }
  };
  const clickReal = function(el) {
    if (!el) return false;
    try { el.scrollIntoView({block:'center', inline:'center'}); } catch (_) {}
    ['pointerdown','mousedown','touchstart','pointerup','mouseup','touchend','click'].forEach(function(name) {
      try { el.dispatchEvent(new MouseEvent(name, { bubbles: true, cancelable: true, view: window })); } catch (_) {}
    });
    try { el.click(); } catch (_) {}
    return true;
  };

  const inputs = Array.from(document.querySelectorAll('input,textarea')).filter(visible);
  const body = norm(document.body ? document.body.innerText : '');
  const phoneInput = inputs.find(function(i) {
    const t = norm([i.name, i.id, i.placeholder, i.getAttribute('aria-label'), i.type, i.inputMode].join(' '));
    const max = Number(i.getAttribute('maxlength') || i.maxLength || 0);
    return /mobile|phone|cell|شماره|موبایل|تلفن/.test(t) || i.type === 'tel' || max === 11;
  });
  const otpInputs = inputs.filter(function(i) {
    const t = norm([i.name, i.id, i.placeholder, i.getAttribute('aria-label'), i.autocomplete, i.type, i.inputMode].join(' '));
    const max = Number(i.getAttribute('maxlength') || i.maxLength || 0);
    const isPhoneText = /mobile|phone|cell|شماره|موبایل|تلفن/.test(t) || i.type === 'tel' || max === 11;
    const isOtpText = /otp|code|verify|verification|کدتایید|کدتأیید|رمزیکبارمصرف/.test(t) || (max >= 4 && max <= 8);
    return isOtpText && !isPhoneText;
  });

  if (phoneInput && otpInputs.length === 0 && !/ارسالمجدد|ویرایش|کدتاییدارسالشده|کدتأییدارسالشده|مرحلهبعد/.test(body)) {
    return 'not_otp_step';
  }

  let input = otpInputs[0];
  if (!input && !phoneInput && inputs.length === 1) input = inputs[0];
  if (!input) return 'no_otp_input';

  input.removeAttribute('readonly');
  input.removeAttribute('disabled');
  input.focus();
  nativeSet(input, code);
  fire(input);

  const current = (input.value || '').replace(/\D/g, '');
  if (current !== code) return 'otp_not_set';

  const all = Array.from(document.querySelectorAll('button,input[type=button],input[type=submit],a,[role=button]')).filter(visible);
  const enabled = all.filter(function(b) {
    return !b.disabled && b.getAttribute('aria-disabled') !== 'true' && !/disabled/.test(b.className || '');
  });
  let btn = enabled.find(function(b) {
    const t = norm([b.innerText, b.textContent, b.value, b.title, b.getAttribute('aria-label')].join(' '));
    return /مرحلهبعد|ادامه|ورود|تایید|تأیید|بررسی|ثبت|بعدی/.test(t);
  });
  if (!btn) btn = enabled.find(function(b) {
    const t = norm([b.innerText, b.textContent, b.value, b.title, b.getAttribute('aria-label')].join(' '));
    return !/ویرایش|بازگشت|لغو|پشتیبانی|کالابرگ|ارسالمجدد/.test(t);
  });

  if (btn) {
    clickReal(btn);
    return 'clicked_otp_submit';
  }

  if (input.form) {
    try { if (input.form.requestSubmit) input.form.requestSubmit(); else input.form.submit(); return 'submitted_otp_form'; } catch (_) {}
  }
  return 'filled_otp_only';
})();
''';
    final result = await _webController.runJavaScriptReturningResult(script);
    final text = result.toString();
    return text.contains('clicked_otp_submit') || text.contains('submitted_otp_form') || text.contains('filled_otp_only');
  }

  Future<void> _resendCode() async {
    if (_resendSeconds > 0) return;
    final phone = _submittedPhone ?? _normalizePhone(_phoneController.text);
    if (!_isValidPhone(phone)) {
      _editPhone();
      return;
    }
    setState(() => _message = 'در حال ارسال مجدد کد...');
    await _retryJavaScript(
      () => _injectPhone(phone),
      attempts: 5,
      delay: const Duration(milliseconds: 800),
    );
    if (!mounted) return;
    setState(() => _message = null);
    _startResendTimer();
  }

  void _editPhone() {
    _timer?.cancel();
    setState(() {
      _stage = AppStage.phone;
      _message = null;
      _otpController.clear();
      _resendSeconds = 0;
    });
    _setLightSystemUi();
    unawaited(_webController.loadRequest(Uri.parse(kInitialUrl)));
  }

  Future<void> _openDirectSite() async {
    setState(() {
      _stage = AppStage.web;
      _message = null;
    });
    _setWebSystemUi();
    await _webController.loadRequest(Uri.parse(kInitialUrl));
  }

  Future<void> _goHomeInWeb() async {
    setState(() {
      _hasMainFrameError = false;
      _progress = 0;
    });
    await _webController.loadRequest(Uri.parse(kInitialUrl));
  }

  Future<void> _reload() async {
    setState(() {
      _hasMainFrameError = false;
      _progress = 0;
    });
    await _webController.reload();
  }

  void _showAboutSheet() {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (context) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(kAppName, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 10),
            const Text(
              'این برنامه فقط برای دسترسی سریع‌تر به سامانه طراحی شده است. شماره موبایل و کد تأیید در برنامه ذخیره نمی‌شود و ورود واقعی از طریق خود سایت انجام می‌شود.',
              style: TextStyle(height: 1.8, color: Color(0xFF4B5563)),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: () {
                Navigator.pop(context);
                _openDirectSite();
              },
              icon: const Icon(Icons.open_in_browser_rounded),
              label: const Text('باز کردن سایت داخل برنامه'),
            ),
          ],
        ),
      ),
    );
  }

  void _showSnack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  void _setLightSystemUi() {
    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: kPageColor,
        statusBarIconBrightness: Brightness.dark,
        systemNavigationBarColor: Colors.white,
        systemNavigationBarIconBrightness: Brightness.dark,
      ),
    );
  }

  void _setWebSystemUi() {
    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: Color(0xFF0B4A7A),
        statusBarIconBrightness: Brightness.light,
        systemNavigationBarColor: Colors.white,
        systemNavigationBarIconBrightness: Brightness.dark,
      ),
    );
  }

  Future<bool> _onWillPop() async {
    if (_stage == AppStage.otp) {
      _editPhone();
      return false;
    }
    if (_stage == AppStage.web && await _webController.canGoBack()) {
      await _webController.goBack();
      return false;
    }
    if (_stage == AppStage.web) {
      setState(() => _stage = AppStage.phone);
      _setLightSystemUi();
      return false;
    }
    final shouldExit = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('خروج از برنامه'),
        content: const Text('می‌خواهید از برنامه خارج شوید؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('خیر')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('خروج')),
        ],
      ),
    );
    return shouldExit ?? false;
  }

  @override
  Widget build(BuildContext context) {
    final showWeb = _stage == AppStage.web;

    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        backgroundColor: kPageColor,
        body: Stack(
          children: [
            Positioned.fill(
              child: Opacity(
                opacity: showWeb ? 1 : 0.01,
                child: IgnorePointer(
                  ignoring: !showWeb,
                  child: _WebArea(
                    controller: _webController,
                    progress: _progress,
                    hasError: _hasMainFrameError,
                    errorText: _errorText,
                    message: _message,
                    onHome: _goHomeInWeb,
                    onReload: _reload,
                    onAbout: _showAboutSheet,
                  ),
                ),
              ),
            ),
            if (_stage == AppStage.phone)
              _PhoneLoginScreen(
                controller: _phoneController,
                isLoading: _submittingPhone,
                message: _message,
                onSubmit: _submitPhone,
                onAbout: _showAboutSheet,
              ),
            if (_stage == AppStage.otp)
              _OtpScreen(
                phone: _submittedPhone ?? _phoneController.text,
                controller: _otpController,
                isLoading: _submittingOtp,
                message: _message,
                resendSeconds: _resendSeconds,
                onSubmit: _submitOtp,
                onEditPhone: _editPhone,
                onResend: _resendCode,
                onContact: () => _openExternal(Uri.parse('tel:0216369')),
                onCalabar: () => _openExternal(Uri.parse('tel:*500*1463%23')),
              ),
          ],
        ),
      ),
    );
  }
}

class _PhoneLoginScreen extends StatelessWidget {
  const _PhoneLoginScreen({
    required this.controller,
    required this.isLoading,
    required this.message,
    required this.onSubmit,
    required this.onAbout,
  });

  final TextEditingController controller;
  final bool isLoading;
  final String? message;
  final VoidCallback onSubmit;
  final VoidCallback onAbout;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: LayoutBuilder(
        builder: (context, constraints) {
          return SingleChildScrollView(
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            child: ConstrainedBox(
              constraints: BoxConstraints(minHeight: constraints.maxHeight),
              child: Column(
                children: [
                  const SizedBox(height: 4),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Padding(
                      padding: const EdgeInsets.only(left: 18),
                      child: IconButton(
                        onPressed: onAbout,
                        icon: const Icon(Icons.info_outline_rounded, color: Color(0xFF1F2937)),
                      ),
                    ),
                  ),
                  const _LogoHeader(),
                  const SizedBox(height: 8),
                  const _SupportIllustration(),
                  const SizedBox(height: 4),
                  _LoginCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const Text(
                          'ورود به برنامه',
                          textAlign: TextAlign.right,
                          style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: Color(0xFF141A1F)),
                        ),
                        const SizedBox(height: 14),
                        const Text(
                          'شماره موبایل خود را وارد کنید',
                          textAlign: TextAlign.right,
                          style: TextStyle(fontSize: 15, color: Color(0xFF3F4750), fontWeight: FontWeight.w500),
                        ),
                        const SizedBox(height: 10),
                        TextField(
                          controller: controller,
                          textAlign: TextAlign.center,
                          keyboardType: TextInputType.phone,
                          textInputAction: TextInputAction.done,
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly,
                            LengthLimitingTextInputFormatter(11),
                          ],
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, letterSpacing: 1.2),
                          decoration: const InputDecoration(
                            hintText: 'به طور مثال: 09123456789',
                            hintStyle: TextStyle(color: Color(0xFF9AA3AD), fontSize: 15, fontWeight: FontWeight.w500),
                          ),
                        ),
                        if (message != null) ...[
                          const SizedBox(height: 12),
                          Text(
                            message!,
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: Color(0xFF2563EB), height: 1.6, fontWeight: FontWeight.w600),
                          ),
                        ],
                        const SizedBox(height: 10),
                        _PrimaryButton(
                          label: isLoading ? 'در حال ارسال...' : 'ارسال کد تأیید',
                          loading: isLoading,
                          onPressed: isLoading ? null : onSubmit,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _OtpScreen extends StatelessWidget {
  const _OtpScreen({
    required this.phone,
    required this.controller,
    required this.isLoading,
    required this.message,
    required this.resendSeconds,
    required this.onSubmit,
    required this.onEditPhone,
    required this.onResend,
    required this.onContact,
    required this.onCalabar,
  });

  final String phone;
  final TextEditingController controller;
  final bool isLoading;
  final String? message;
  final int resendSeconds;
  final VoidCallback onSubmit;
  final VoidCallback onEditPhone;
  final VoidCallback onResend;
  final VoidCallback onContact;
  final VoidCallback onCalabar;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: LayoutBuilder(
        builder: (context, constraints) {
          return SizedBox(
            height: constraints.maxHeight,
            child: Column(
              children: [
                const SizedBox(height: 10),
                Expanded(
                  child: _LoginCard(
                    topRadiusOnly: true,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const Text(
                          'ورود به برنامه',
                          textAlign: TextAlign.right,
                          style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: Color(0xFF141A1F)),
                        ),
                        const SizedBox(height: 14),
                        Wrap(
                          alignment: WrapAlignment.start,
                          crossAxisAlignment: WrapCrossAlignment.center,
                          children: [
                            Text(
                              'کد تأیید ارسال شده به شماره $phone را وارد کنید  ',
                              style: const TextStyle(fontSize: 14.5, color: Color(0xFF2E343B), height: 1.7),
                            ),
                            GestureDetector(
                              onTap: onEditPhone,
                              child: const Text(
                                'ویرایش',
                                style: TextStyle(fontSize: 14.5, color: kBlueColor, fontWeight: FontWeight.w800),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: controller,
                          textAlign: TextAlign.center,
                          keyboardType: TextInputType.number,
                          textInputAction: TextInputAction.done,
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly,
                            LengthLimitingTextInputFormatter(6),
                          ],
                          style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800, letterSpacing: 3),
                          decoration: const InputDecoration(
                            hintText: 'کد تأیید ۶ رقمی',
                            hintStyle: TextStyle(color: Color(0xFF8D96A0), fontSize: 16, fontWeight: FontWeight.w700, letterSpacing: 0),
                          ),
                        ),
                        const SizedBox(height: 14),
                        Center(
                          child: resendSeconds > 0
                              ? Text(
                                  'ارسال مجدد کد تأیید تا ${_formatTime(resendSeconds)}',
                                  style: const TextStyle(fontSize: 14, color: Color(0xFF4B5563), fontWeight: FontWeight.w600),
                                )
                              : TextButton(
                                  onPressed: onResend,
                                  child: const Text('ارسال مجدد کد تأیید'),
                                ),
                        ),
                        if (message != null) ...[
                          const SizedBox(height: 12),
                          Text(
                            message!,
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: Color(0xFF2563EB), height: 1.6, fontWeight: FontWeight.w600),
                          ),
                        ],
                        const Spacer(),
                        _OutlineActionButton(label: 'تماس با پشتیبانی', onPressed: onContact),
                        const SizedBox(height: 10),
                        _OutlineActionButton(label: 'استعلام کالابرگ', onPressed: onCalabar),
                        const SizedBox(height: 10),
                        _PrimaryButton(
                          label: isLoading ? 'در حال بررسی...' : 'مرحله بعد',
                          loading: isLoading,
                          onPressed: isLoading ? null : onSubmit,
                          disabledColor: const Color(0xFFE9ECEF),
                          disabledTextColor: const Color(0xFF8D939A),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  static String _formatTime(int seconds) {
    final m = (seconds ~/ 60).toString().padLeft(2, '0');
    final s = (seconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }
}

class _WebArea extends StatelessWidget {
  const _WebArea({
    required this.controller,
    required this.progress,
    required this.hasError,
    required this.errorText,
    required this.message,
    required this.onHome,
    required this.onReload,
    required this.onAbout,
  });

  final WebViewController controller;
  final int progress;
  final bool hasError;
  final String errorText;
  final String? message;
  final VoidCallback onHome;
  final VoidCallback onReload;
  final VoidCallback onAbout;

  @override
  Widget build(BuildContext context) {
    final showProgress = progress > 0 && progress < 100;
    return Column(
      children: [
        Container(
          padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top),
          color: const Color(0xFF0B4A7A),
          child: SizedBox(
            height: 58,
            child: Row(
              children: [
                IconButton(onPressed: onAbout, icon: const Icon(Icons.info_outline_rounded, color: Colors.white)),
                IconButton(onPressed: onReload, icon: const Icon(Icons.refresh_rounded, color: Colors.white)),
                IconButton(onPressed: onHome, icon: const Icon(Icons.home_rounded, color: Colors.white)),
                const Spacer(),
                const Text(
                  kAppName,
                  style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900),
                ),
                const SizedBox(width: 18),
              ],
            ),
          ),
        ),
        if (showProgress)
          LinearProgressIndicator(
            value: progress / 100,
            minHeight: 3,
            backgroundColor: Colors.transparent,
            color: kBlueColor,
          ),
        if (message != null)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            color: const Color(0xFFEFF6FF),
            child: Text(message!, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFF1D4ED8), fontWeight: FontWeight.w700)),
          ),
        Expanded(
          child: Stack(
            children: [
              WebViewWidget(controller: controller),
              if (hasError)
                _ErrorView(
                  message: errorText,
                  onRetry: onReload,
                  onHome: onHome,
                ),
            ],
          ),
        ),
      ],
    );
  }
}

class _LogoHeader extends StatelessWidget {
  const _LogoHeader();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: const [
        Text(
          'شمیم',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 42, fontWeight: FontWeight.w900, color: Color(0xFF151A1E), height: 0.95),
        ),
        SizedBox(height: 4),
        Text(
          'شبکه ملی یارانه‌های متمرکز',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: Color(0xFF181D23)),
        ),
        SizedBox(height: 8),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 32),
          child: Text(
            'شما می‌توانید از طریق کد دستوری #۱۴۶۳*۵۰۰* نیز جهت مشاهده اعتبار اقدام نمایید.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 14.5, height: 1.55, color: Color(0xFF4C5560), fontWeight: FontWeight.w500),
          ),
        ),
      ],
    );
  }
}

class _SupportIllustration extends StatelessWidget {
  const _SupportIllustration();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 185,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Positioned(
            bottom: 10,
            child: Container(
              width: 205,
              height: 135,
              decoration: BoxDecoration(
                color: const Color(0xFFFFE7B8),
                borderRadius: BorderRadius.circular(28),
                boxShadow: const [BoxShadow(color: Color(0x16000000), blurRadius: 18, offset: Offset(0, 10))],
              ),
              child: const Icon(Icons.shopping_bag_rounded, size: 88, color: Color(0xFFF3C766)),
            ),
          ),
          const Positioned(left: 112, top: 32, child: _FoodItem(color: Color(0xFFEAC08A), width: 32, height: 86)),
          const Positioned(left: 235, top: 48, child: _FoodItem(color: Color(0xFFFF7A59), width: 34, height: 78)),
          const Positioned(right: 125, top: 48, child: _FoodItem(color: Color(0xFFF0F6FA), width: 32, height: 82)),
          Positioned(
            right: 96,
            top: 46,
            child: Transform.rotate(
              angle: -0.65,
              child: Container(width: 25, height: 92, decoration: BoxDecoration(color: const Color(0xFF3FBF50), borderRadius: BorderRadius.circular(20))),
            ),
          ),
          Positioned(
            right: 135,
            bottom: 40,
            child: Container(
              width: 54,
              height: 54,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(36),
                boxShadow: const [BoxShadow(color: Color(0x1A000000), blurRadius: 14, offset: Offset(0, 7))],
              ),
              child: const Icon(Icons.check_rounded, color: Color(0xFF2CC95A), size: 36),
            ),
          ),
        ],
      ),
    );
  }
}

class _FoodItem extends StatelessWidget {
  const _FoodItem({required this.color, required this.width, required this.height});
  final Color color;
  final double width;
  final double height;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(26),
        boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 10, offset: Offset(0, 6))],
      ),
    );
  }
}

class _LoginCard extends StatelessWidget {
  const _LoginCard({required this.child, this.topRadiusOnly = false, this.minHeight});
  final Widget child;
  final bool topRadiusOnly;
  final double? minHeight;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      constraints: BoxConstraints(minHeight: minHeight ?? 0),
      padding: const EdgeInsets.fromLTRB(24, 22, 24, 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: topRadiusOnly
            ? const BorderRadius.vertical(top: Radius.circular(34))
            : const BorderRadius.vertical(top: Radius.circular(34)),
        boxShadow: const [BoxShadow(color: Color(0x08000000), blurRadius: 24, offset: Offset(0, -8))],
      ),
      child: child,
    );
  }
}

class _PrimaryButton extends StatelessWidget {
  const _PrimaryButton({
    required this.label,
    required this.onPressed,
    this.loading = false,
    this.disabledColor,
    this.disabledTextColor,
  });

  final String label;
  final VoidCallback? onPressed;
  final bool loading;
  final Color? disabledColor;
  final Color? disabledTextColor;

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null;
    return SizedBox(
      height: 58,
      child: FilledButton(
        onPressed: onPressed,
        style: FilledButton.styleFrom(
          backgroundColor: enabled ? kPrimaryColor : (disabledColor ?? const Color(0xFFE9ECEF)),
          foregroundColor: enabled ? Colors.white : (disabledTextColor ?? const Color(0xFF8D939A)),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
        ),
        child: loading
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white),
              )
            : Text(label),
      ),
    );
  }
}

class _OutlineActionButton extends StatelessWidget {
  const _OutlineActionButton({required this.label, required this.onPressed});
  final String label;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 54,
      child: OutlinedButton(
        onPressed: onPressed,
        style: OutlinedButton.styleFrom(
          side: const BorderSide(color: Color(0xFF8A8F95), width: 1.2),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          foregroundColor: const Color(0xFF6B7178),
          textStyle: const TextStyle(fontSize: 16.5, fontWeight: FontWeight.w900),
        ),
        child: Text(label),
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.message, required this.onRetry, required this.onHome});

  final String message;
  final VoidCallback onRetry;
  final VoidCallback onHome;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: kPageColor,
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
              boxShadow: const [BoxShadow(color: Color(0x1A000000), blurRadius: 24, offset: Offset(0, 12))],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.wifi_off_rounded, size: 54, color: Color(0xFF0B4A7A)),
                const SizedBox(height: 14),
                const Text('اتصال برقرار نشد', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                Text(message, textAlign: TextAlign.center, style: const TextStyle(height: 1.7, color: Color(0xFF4B5563))),
                const SizedBox(height: 18),
                Row(
                  children: [
                    Expanded(child: OutlinedButton.icon(onPressed: onHome, icon: const Icon(Icons.home_rounded), label: const Text('خانه'))),
                    const SizedBox(width: 10),
                    Expanded(child: FilledButton.icon(onPressed: onRetry, icon: const Icon(Icons.refresh_rounded), label: const Text('تلاش مجدد'))),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
