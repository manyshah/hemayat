# استعلام کالابرگ و یارانه - v2.1 R8 Fix

نسخه ساده WebView با تبلیغ بنری Adivery، آیکون انتخاب‌شده، پکیج‌نیم `com.manyshah.hemayat`، نسخه `1.0.0+1` و خروجی signed APK.

اصلاح این نسخه:
- رفع خطای R8 / Missing classes مربوط به Adivery و کلاس‌های `com.mbridge.*`
- اضافه شدن proguard/dontwarn rules در Workflow هنگام ساخت پروژه Android تمیز

نکته امنیتی: این ZIP شامل keystore و key.properties است؛ ریپوی GitHub باید Private بماند.
