# سامانه‌یار حمایت - Simple WebView

نسخه ساده و پایدار اپ:

- فقط WebView مستقیم سایت `https://hemayat.sfara.ir/`
- Splash Screen ابتدایی
- نوار بالا فقط شامل نام برنامه و دکمه Refresh
- حذف کامل فرم ورود اختصاصی Flutter
- حفظ رفتار طبیعی سایت برای ورود، ارسال کد و تأیید کد
- خروجی signed APK از طریق GitHub Actions

> نکته امنیتی: پوشه `android_signing` شامل keystore است. ریپازیتوری را Private نگه دارید.
