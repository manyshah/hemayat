import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

const String kInitialUrl = 'https://hemayat.sfara.ir/';
const String kAppName = 'سامانه‌یار حمایت';
const Color kPrimaryColor = Color(0xFF0F1720);
const Color kBlueColor = Color(0xFF357DEE);
const Color kPageColor = Color(0xFFF7F7F7);

enum AppStage { phone, otp, web }

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: kPageColor,
      statusBarIconBrightness: Brightness.dark,
      systemNavigationBarColor: Colors.white,
      systemNavigationBarIconBrightness: Brightness.dark,
    ),
  );
  runApp(const HemayatWebApp());
}

class HemayatWebApp extends StatelessWidget {
  const HemayatWebApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: kAppName,
      debugShowCheckedModeBanner: false,
      locale: const Locale('fa', 'IR'),
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Roboto',
        scaffoldBackgroundColor: kPageColor,
        colorScheme: ColorScheme.fromSeed(
          seedColor: kBlueColor,
          primary: kBlueColor,
          secondary: const Color(0xFF16A34A),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: const BorderSide(color: Color(0xFFE1E5EA)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: const BorderSide(color: Color(0xFFE1E5EA)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: const BorderSide(color: kBlueColor, width: 1.2),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: const BorderSide(color: Color(0xFFEF4444)),
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
        ),
      ),
      builder: (context, child) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: const HemayatShell(),
    );
  }
}

class HemayatShell extends StatefulWidget {
  const HemayatShell({super.key});

  @override
  State<HemayatShell> createState() => _HemayatShellState();
}

class _HemayatShellState extends State<HemayatShell> {
  late final WebViewController _webController;
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _otpController = TextEditingController();

  AppStage _stage = AppStage.phone;
  int _progress = 0;
  bool _hasMainFrameError = false;
  bool _submittingPhone = false;
  bool _submittingOtp = false;
  bool _webPrepared = false;
  String _errorText = 'صفحه باز نشد. اینترنت را بررسی کنید و دوباره تلاش کنید.';
  String? _submittedPhone;
  String? _message;
  Timer? _timer;
  int _resendSeconds = 0;

  @override
  void initState() {
    super.initState();
    _webController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.white)
      ..enableZoom(false)
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (progress) {
            if (!mounted) return;
            setState(() => _progress = progress);
          },
          onPageStarted: (_) {
            if (!mounted) return;
            setState(() {
              _hasMainFrameError = false;
              _progress = 0;
            });
          },
          onPageFinished: (_) {
            if (!mounted) return;
            setState(() {
              _webPrepared = true;
              _progress = 100;
            });
          },
          onWebResourceError: (error) {
            if (!mounted || error.isForMainFrame != true) return;
            setState(() {
              _hasMainFrameError = true;
              _errorText = error.description.isNotEmpty
                  ? error.description
                  : 'اتصال برقرار نشد.';
            });
          },
          onNavigationRequest: (request) {
            final uri = Uri.tryParse(request.url);
            if (uri == null) return NavigationDecision.navigate;
            if (<String>{'tel', 'mailto', 'sms', 'intent', 'market'}.contains(uri.scheme)) {
              unawaited(_openExternal(uri));
              return NavigationDecision.prevent;
            }
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadRequest(Uri.parse(kInitialUrl));
  }

  @override
  void dispose() {
    _timer?.cancel();
    _phoneController.dispose();
    _otpController.dispose();
    super.dispose();
  }

  Future<void> _openExternal(Uri uri) async {
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      _showSnack('امکان باز کردن این لینک وجود ندارد.');
    }
  }

  String _normalizePhone(String input) {
    final english = input
        .replaceAll('۰', '0')
        .replaceAll('۱', '1')
        .replaceAll('۲', '2')
        .replaceAll('۳', '3')
        .replaceAll('۴', '4')
        .replaceAll('۵', '5')
        .replaceAll('۶', '6')
        .replaceAll('۷', '7')
        .replaceAll('۸', '8')
        .replaceAll('۹', '9')
        .replaceAll('٠', '0')
        .replaceAll('١', '1')
        .replaceAll('٢', '2')
        .replaceAll('٣', '3')
        .replaceAll('٤', '4')
        .replaceAll('٥', '5')
        .replaceAll('٦', '6')
        .replaceAll('٧', '7')
        .replaceAll('٨', '8')
        .replaceAll('٩', '9');
    return english.replaceAll(RegExp(r'\D'), '');
  }

  bool _isValidPhone(String phone) => RegExp(r'^09\d{9}$').hasMatch(phone);

  void _startResendTimer() {
    _timer?.cancel();
    setState(() => _resendSeconds = 60);
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      if (_resendSeconds <= 1) {
        timer.cancel();
        setState(() => _resendSeconds = 0);
      } else {
        setState(() => _resendSeconds -= 1);
      }
    });
  }

  Future<void> _submitPhone() async {
    final phone = _normalizePhone(_phoneController.text);
    if (!_isValidPhone(phone)) {
      setState(() => _message = 'شماره موبایل را به صورت ۱۱ رقمی و با 09 وارد کنید.');
      return;
    }

    setState(() {
      _submittingPhone = true;
      _message = 'در حال اتصال به سامانه و ارسال شماره...';
      _submittedPhone = phone;
      _hasMainFrameError = false;
    });

    try {
      await _webController.loadRequest(Uri.parse(kInitialUrl));
      final ok = await _retryJavaScript(
        () => _injectPhone(phone),
        attempts: 9,
        delay: const Duration(milliseconds: 850),
      );

      if (!mounted) return;
      setState(() {
        _submittingPhone = false;
        _stage = AppStage.otp;
        _message = ok
            ? null
            : 'شماره وارد شد. اگر کد ارسال نشد، از دکمه ویرایش شماره دوباره تلاش کنید یا سایت را مستقیم باز کنید.';
      });
      _startResendTimer();
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _submittingPhone = false;
        _message = 'اتصال انجام نشد. اینترنت را بررسی کنید و دوباره تلاش کنید.';
      });
    }
  }

  Future<void> _submitOtp() async {
    final code = _normalizePhone(_otpController.text);
    if (code.length < 4) {
      setState(() => _message = 'کد تأیید را کامل وارد کنید.');
      return;
    }

    setState(() {
      _submittingOtp = true;
      _message = 'در حال بررسی کد تأیید...';
      _hasMainFrameError = false;
    });

    try {
      final ok = await _retryJavaScript(
        () => _injectOtp(code),
        attempts: 7,
        delay: const Duration(milliseconds: 750),
      );

      if (!mounted) return;
      setState(() {
        _submittingOtp = false;
        _stage = AppStage.web;
        _message = ok ? null : 'اگر ورود کامل نشد، کد را داخل صفحه سامانه وارد کنید.';
      });
      _setWebSystemUi();
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _submittingOtp = false;
        _stage = AppStage.web;
        _message = 'صفحه سامانه باز شد. کد را داخل سایت بررسی کنید.';
      });
      _setWebSystemUi();
    }
  }

  Future<bool> _retryJavaScript(
    Future<bool> Function() action, {
    required int attempts,
    required Duration delay,
  }) async {
    for (var i = 0; i < attempts; i++) {
      await Future.delayed(i == 0 && _webPrepared ? Duration.zero : delay);
      try {
        if (await action()) return true;
      } catch (_) {
        // Try again. Some government pages need a little more time after load.
      }
    }
    return false;
  }

  Future<bool> _injectPhone(String phone) async {
    final script = '''
(function() {
  const phone = ${jsonEncode(phone)};
  const norm = function(s) { return (s || '').replace(/\\s+/g, ''); };
  const visible = function(el) {
    if (!el) return false;
    const st = window.getComputedStyle(el);
    const r = el.getBoundingClientRect();
    return st.display !== 'none' && st.visibility !== 'hidden' && r.width > 0 && r.height > 0;
  };
  const fire = function(el) {
    ['input','change','keyup','keydown','blur'].forEach(function(name) {
      el.dispatchEvent(new Event(name, { bubbles: true }));
    });
  };
  const inputs = Array.from(document.querySelectorAll('input')).filter(visible);
  let input = inputs.find(function(i) {
    const text = norm([i.name, i.id, i.placeholder, i.getAttribute('aria-label'), i.type].join(' '));
    return /mobile|phone|cell|شماره|موبایل|تلفن/.test(text) || i.maxLength === 11 || i.inputMode === 'numeric' || i.type === 'tel';
  });
  if (!input) input = inputs.find(function(i) { return /tel|number|text/.test(i.type || 'text'); });
  if (!input) return 'no_input';
  input.removeAttribute('readonly');
  input.focus();
  input.value = phone;
  fire(input);
  const clickables = Array.from(document.querySelectorAll('button,input[type=button],input[type=submit],a,[role=button]')).filter(visible);
  let btn = clickables.find(function(b) {
    const t = norm([b.innerText, b.textContent, b.value, b.getAttribute('aria-label')].join(' '));
    return /ادامه|ارسال|تایید|تأیید|ورود|کد/.test(t) && !b.disabled;
  });
  if (!btn) btn = clickables.find(function(b) { return !b.disabled; });
  if (btn) { btn.click(); return 'clicked'; }
  if (input.form) {
    if (input.form.requestSubmit) input.form.requestSubmit(); else input.form.submit();
    return 'submitted';
  }
  return 'filled';
})();
''';
    final result = await _webController.runJavaScriptReturningResult(script);
    final text = result.toString();
    return text.contains('clicked') || text.contains('submitted') || text.contains('filled');
  }

  Future<bool> _injectOtp(String code) async {
    final script = '''
(function() {
  const code = ${jsonEncode(code)};
  const norm = function(s) { return (s || '').replace(/\\s+/g, ''); };
  const visible = function(el) {
    if (!el) return false;
    const st = window.getComputedStyle(el);
    const r = el.getBoundingClientRect();
    return st.display !== 'none' && st.visibility !== 'hidden' && r.width > 0 && r.height > 0;
  };
  const fire = function(el) {
    ['input','change','keyup','keydown','blur'].forEach(function(name) {
      el.dispatchEvent(new Event(name, { bubbles: true }));
    });
  };
  const inputs = Array.from(document.querySelectorAll('input')).filter(visible);
  let input = inputs.find(function(i) {
    const text = norm([i.name, i.id, i.placeholder, i.getAttribute('aria-label'), i.type].join(' '));
    return /otp|code|verify|verification|کد|تایید|تأیید/.test(text) || i.maxLength === 6 || i.inputMode === 'numeric';
  });
  if (!input) input = inputs[inputs.length - 1];
  if (!input) return 'no_input';
  input.removeAttribute('readonly');
  input.focus();
  input.value = code;
  fire(input);
  const clickables = Array.from(document.querySelectorAll('button,input[type=button],input[type=submit],a,[role=button]')).filter(visible);
  let btn = clickables.find(function(b) {
    const t = norm([b.innerText, b.textContent, b.value, b.getAttribute('aria-label')].join(' '));
    return /مرحلهبعد|ادامه|ورود|تایید|تأیید|بررسی|ثبت/.test(t) && !b.disabled;
  });
  if (!btn) btn = clickables.find(function(b) { return !b.disabled; });
  if (btn) { btn.click(); return 'clicked'; }
  if (input.form) {
    if (input.form.requestSubmit) input.form.requestSubmit(); else input.form.submit();
    return 'submitted';
  }
  return 'filled';
})();
''';
    final result = await _webController.runJavaScriptReturningResult(script);
    final text = result.toString();
    return text.contains('clicked') || text.contains('submitted') || text.contains('filled');
  }

  Future<void> _resendCode() async {
    if (_resendSeconds > 0) return;
    final phone = _submittedPhone ?? _normalizePhone(_phoneController.text);
    if (!_isValidPhone(phone)) {
      _editPhone();
      return;
    }
    setState(() => _message = 'در حال ارسال مجدد کد...');
    await _retryJavaScript(
      () => _injectPhone(phone),
      attempts: 5,
      delay: const Duration(milliseconds: 800),
    );
    if (!mounted) return;
    setState(() => _message = null);
    _startResendTimer();
  }

  void _editPhone() {
    _timer?.cancel();
    setState(() {
      _stage = AppStage.phone;
      _message = null;
      _otpController.clear();
      _resendSeconds = 0;
    });
    _setLightSystemUi();
  }

  Future<void> _openDirectSite() async {
    setState(() {
      _stage = AppStage.web;
      _message = null;
    });
    _setWebSystemUi();
    await _webController.loadRequest(Uri.parse(kInitialUrl));
  }

  Future<void> _goHomeInWeb() async {
    setState(() {
      _hasMainFrameError = false;
      _progress = 0;
    });
    await _webController.loadRequest(Uri.parse(kInitialUrl));
  }

  Future<void> _reload() async {
    setState(() {
      _hasMainFrameError = false;
      _progress = 0;
    });
    await _webController.reload();
  }

  void _showAboutSheet() {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (context) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(kAppName, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 10),
            const Text(
              'این برنامه فقط برای دسترسی سریع‌تر به سامانه طراحی شده است. شماره موبایل و کد تأیید در برنامه ذخیره نمی‌شود و ورود واقعی از طریق خود سایت انجام می‌شود.',
              style: TextStyle(height: 1.8, color: Color(0xFF4B5563)),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: () {
                Navigator.pop(context);
                _openDirectSite();
              },
              icon: const Icon(Icons.open_in_browser_rounded),
              label: const Text('باز کردن سایت داخل برنامه'),
            ),
          ],
        ),
      ),
    );
  }

  void _showSnack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  void _setLightSystemUi() {
    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: kPageColor,
        statusBarIconBrightness: Brightness.dark,
        systemNavigationBarColor: Colors.white,
        systemNavigationBarIconBrightness: Brightness.dark,
      ),
    );
  }

  void _setWebSystemUi() {
    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: Color(0xFF0B4A7A),
        statusBarIconBrightness: Brightness.light,
        systemNavigationBarColor: Colors.white,
        systemNavigationBarIconBrightness: Brightness.dark,
      ),
    );
  }

  Future<bool> _onWillPop() async {
    if (_stage == AppStage.otp) {
      _editPhone();
      return false;
    }
    if (_stage == AppStage.web && await _webController.canGoBack()) {
      await _webController.goBack();
      return false;
    }
    if (_stage == AppStage.web) {
      setState(() => _stage = AppStage.phone);
      _setLightSystemUi();
      return false;
    }
    final shouldExit = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('خروج از برنامه'),
        content: const Text('می‌خواهید از برنامه خارج شوید؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('خیر')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('خروج')),
        ],
      ),
    );
    return shouldExit ?? false;
  }

  @override
  Widget build(BuildContext context) {
    final showWeb = _stage == AppStage.web;

    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        backgroundColor: kPageColor,
        body: Stack(
          children: [
            Positioned.fill(
              child: Opacity(
                opacity: showWeb ? 1 : 0.01,
                child: IgnorePointer(
                  ignoring: !showWeb,
                  child: _WebArea(
                    controller: _webController,
                    progress: _progress,
                    hasError: _hasMainFrameError,
                    errorText: _errorText,
                    message: _message,
                    onHome: _goHomeInWeb,
                    onReload: _reload,
                    onAbout: _showAboutSheet,
                  ),
                ),
              ),
            ),
            if (_stage == AppStage.phone)
              _PhoneLoginScreen(
                controller: _phoneController,
                isLoading: _submittingPhone,
                message: _message,
                onSubmit: _submitPhone,
                onAbout: _showAboutSheet,
                onOpenSite: _openDirectSite,
              ),
            if (_stage == AppStage.otp)
              _OtpScreen(
                phone: _submittedPhone ?? _phoneController.text,
                controller: _otpController,
                isLoading: _submittingOtp,
                message: _message,
                resendSeconds: _resendSeconds,
                onSubmit: _submitOtp,
                onEditPhone: _editPhone,
                onResend: _resendCode,
                onContact: () => _openExternal(Uri.parse('tel:0216369')),
                onCalabar: () => _openExternal(Uri.parse('tel:*500*1463%23')),
                onOpenSite: _openDirectSite,
              ),
          ],
        ),
      ),
    );
  }
}

class _PhoneLoginScreen extends StatelessWidget {
  const _PhoneLoginScreen({
    required this.controller,
    required this.isLoading,
    required this.message,
    required this.onSubmit,
    required this.onAbout,
    required this.onOpenSite,
  });

  final TextEditingController controller;
  final bool isLoading;
  final String? message;
  final VoidCallback onSubmit;
  final VoidCallback onAbout;
  final VoidCallback onOpenSite;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: LayoutBuilder(
        builder: (context, constraints) {
          return SingleChildScrollView(
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            child: ConstrainedBox(
              constraints: BoxConstraints(minHeight: constraints.maxHeight),
              child: Column(
                children: [
                  const SizedBox(height: 18),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Padding(
                      padding: const EdgeInsets.only(left: 18),
                      child: IconButton(
                        onPressed: onAbout,
                        icon: const Icon(Icons.info_outline_rounded, color: Color(0xFF1F2937)),
                      ),
                    ),
                  ),
                  const _LogoHeader(),
                  const SizedBox(height: 18),
                  const _SupportIllustration(),
                  const SizedBox(height: 12),
                  _LoginCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const Text(
                          'ورود به برنامه',
                          textAlign: TextAlign.right,
                          style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: Color(0xFF141A1F)),
                        ),
                        const SizedBox(height: 22),
                        const Text(
                          'شماره موبایل خود را وارد کنید',
                          textAlign: TextAlign.right,
                          style: TextStyle(fontSize: 17, color: Color(0xFF3F4750), fontWeight: FontWeight.w500),
                        ),
                        const SizedBox(height: 16),
                        TextField(
                          controller: controller,
                          textAlign: TextAlign.center,
                          keyboardType: TextInputType.phone,
                          textInputAction: TextInputAction.done,
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly,
                            LengthLimitingTextInputFormatter(11),
                          ],
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700, letterSpacing: 1.4),
                          decoration: const InputDecoration(
                            hintText: 'به طور مثال: 09123456789',
                            hintStyle: TextStyle(color: Color(0xFF9AA3AD), fontSize: 17, fontWeight: FontWeight.w500),
                          ),
                          onSubmitted: (_) { if (!isLoading) onSubmit(); },
                        ),
                        if (message != null) ...[
                          const SizedBox(height: 12),
                          Text(
                            message!,
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: Color(0xFF2563EB), height: 1.6, fontWeight: FontWeight.w600),
                          ),
                        ],
                        const SizedBox(height: 26),
                        _PrimaryButton(
                          label: isLoading ? 'در حال ارسال...' : 'ارسال کد تأیید',
                          loading: isLoading,
                          onPressed: isLoading ? null : onSubmit,
                        ),
                        const SizedBox(height: 14),
                        TextButton(
                          onPressed: isLoading ? null : onOpenSite,
                          child: const Text('ورود مستقیم از طریق سایت'),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _OtpScreen extends StatelessWidget {
  const _OtpScreen({
    required this.phone,
    required this.controller,
    required this.isLoading,
    required this.message,
    required this.resendSeconds,
    required this.onSubmit,
    required this.onEditPhone,
    required this.onResend,
    required this.onContact,
    required this.onCalabar,
    required this.onOpenSite,
  });

  final String phone;
  final TextEditingController controller;
  final bool isLoading;
  final String? message;
  final int resendSeconds;
  final VoidCallback onSubmit;
  final VoidCallback onEditPhone;
  final VoidCallback onResend;
  final VoidCallback onContact;
  final VoidCallback onCalabar;
  final VoidCallback onOpenSite;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: LayoutBuilder(
        builder: (context, constraints) {
          return SingleChildScrollView(
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            child: ConstrainedBox(
              constraints: BoxConstraints(minHeight: constraints.maxHeight),
              child: Column(
                children: [
                  const SizedBox(height: 40),
                  _LoginCard(
                    topRadiusOnly: true,
                    minHeight: constraints.maxHeight - 40,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const Text(
                          'ورود به برنامه',
                          textAlign: TextAlign.right,
                          style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: Color(0xFF141A1F)),
                        ),
                        const SizedBox(height: 26),
                        Wrap(
                          alignment: WrapAlignment.start,
                          crossAxisAlignment: WrapCrossAlignment.center,
                          children: [
                            Text(
                              'کد تأیید ارسال شده به شماره $phone را وارد کنید  ',
                              style: const TextStyle(fontSize: 16.5, color: Color(0xFF2E343B), height: 1.7),
                            ),
                            GestureDetector(
                              onTap: onEditPhone,
                              child: const Text(
                                'ویرایش',
                                style: TextStyle(fontSize: 16.5, color: kBlueColor, fontWeight: FontWeight.w800),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 20),
                        TextField(
                          controller: controller,
                          textAlign: TextAlign.center,
                          keyboardType: TextInputType.number,
                          textInputAction: TextInputAction.done,
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly,
                            LengthLimitingTextInputFormatter(6),
                          ],
                          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, letterSpacing: 4),
                          decoration: const InputDecoration(
                            hintText: 'کد تأیید ۶ رقمی',
                            hintStyle: TextStyle(color: Color(0xFF8D96A0), fontSize: 19, fontWeight: FontWeight.w700, letterSpacing: 0),
                          ),
                          onSubmitted: (_) { if (!isLoading) onSubmit(); },
                        ),
                        const SizedBox(height: 24),
                        Center(
                          child: resendSeconds > 0
                              ? Text(
                                  'ارسال مجدد کد تأیید تا ${_formatTime(resendSeconds)}',
                                  style: const TextStyle(fontSize: 16, color: Color(0xFF4B5563), fontWeight: FontWeight.w600),
                                )
                              : TextButton(
                                  onPressed: onResend,
                                  child: const Text('ارسال مجدد کد تأیید'),
                                ),
                        ),
                        if (message != null) ...[
                          const SizedBox(height: 12),
                          Text(
                            message!,
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: Color(0xFF2563EB), height: 1.6, fontWeight: FontWeight.w600),
                          ),
                        ],
                        SizedBox(height: constraints.maxHeight * 0.34),
                        _OutlineActionButton(label: 'تماس با پشتیبانی', onPressed: onContact),
                        const SizedBox(height: 16),
                        _OutlineActionButton(label: 'استعلام کالابرگ', onPressed: onCalabar),
                        const SizedBox(height: 16),
                        _PrimaryButton(
                          label: isLoading ? 'در حال بررسی...' : 'مرحله بعد',
                          loading: isLoading,
                          onPressed: isLoading ? null : onSubmit,
                          disabledColor: const Color(0xFFE9ECEF),
                          disabledTextColor: const Color(0xFF8D939A),
                        ),
                        const SizedBox(height: 12),
                        TextButton(onPressed: onOpenSite, child: const Text('مشاهده صفحه اصلی سامانه')),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  static String _formatTime(int seconds) {
    final m = (seconds ~/ 60).toString().padLeft(2, '0');
    final s = (seconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }
}

class _WebArea extends StatelessWidget {
  const _WebArea({
    required this.controller,
    required this.progress,
    required this.hasError,
    required this.errorText,
    required this.message,
    required this.onHome,
    required this.onReload,
    required this.onAbout,
  });

  final WebViewController controller;
  final int progress;
  final bool hasError;
  final String errorText;
  final String? message;
  final VoidCallback onHome;
  final VoidCallback onReload;
  final VoidCallback onAbout;

  @override
  Widget build(BuildContext context) {
    final showProgress = progress > 0 && progress < 100;
    return Column(
      children: [
        Container(
          padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top),
          color: const Color(0xFF0B4A7A),
          child: SizedBox(
            height: 58,
            child: Row(
              children: [
                IconButton(onPressed: onAbout, icon: const Icon(Icons.info_outline_rounded, color: Colors.white)),
                IconButton(onPressed: onReload, icon: const Icon(Icons.refresh_rounded, color: Colors.white)),
                IconButton(onPressed: onHome, icon: const Icon(Icons.home_rounded, color: Colors.white)),
                const Spacer(),
                const Text(
                  kAppName,
                  style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900),
                ),
                const SizedBox(width: 18),
              ],
            ),
          ),
        ),
        if (showProgress)
          LinearProgressIndicator(
            value: progress / 100,
            minHeight: 3,
            backgroundColor: Colors.transparent,
            color: kBlueColor,
          ),
        if (message != null)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            color: const Color(0xFFEFF6FF),
            child: Text(message!, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFF1D4ED8), fontWeight: FontWeight.w700)),
          ),
        Expanded(
          child: Stack(
            children: [
              WebViewWidget(controller: controller),
              if (hasError)
                _ErrorView(
                  message: errorText,
                  onRetry: onReload,
                  onHome: onHome,
                ),
            ],
          ),
        ),
      ],
    );
  }
}

class _LogoHeader extends StatelessWidget {
  const _LogoHeader();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: const [
        Text(
          'شمیم',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 52, fontWeight: FontWeight.w900, color: Color(0xFF151A1E), height: 0.95),
        ),
        SizedBox(height: 4),
        Text(
          'شبکه ملی یارانه‌های متمرکز',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Color(0xFF181D23)),
        ),
        SizedBox(height: 12),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 32),
          child: Text(
            'شما می‌توانید از طریق کد دستوری #۱۴۶۳*۵۰۰* نیز جهت مشاهده اعتبار اقدام نمایید.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 17, height: 1.7, color: Color(0xFF4C5560), fontWeight: FontWeight.w500),
          ),
        ),
      ],
    );
  }
}

class _SupportIllustration extends StatelessWidget {
  const _SupportIllustration();

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 270,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Positioned(
            bottom: 10,
            child: Container(
              width: 255,
              height: 185,
              decoration: BoxDecoration(
                color: const Color(0xFFFFE7B8),
                borderRadius: BorderRadius.circular(34),
                boxShadow: const [BoxShadow(color: Color(0x16000000), blurRadius: 18, offset: Offset(0, 10))],
              ),
              child: const Icon(Icons.shopping_bag_rounded, size: 120, color: Color(0xFFF3C766)),
            ),
          ),
          const Positioned(left: 120, top: 58, child: _FoodItem(color: Color(0xFFEAC08A), width: 44, height: 120)),
          const Positioned(left: 250, top: 80, child: _FoodItem(color: Color(0xFFFF7A59), width: 46, height: 110)),
          const Positioned(right: 135, top: 78, child: _FoodItem(color: Color(0xFFF0F6FA), width: 44, height: 115)),
          Positioned(
            right: 96,
            top: 68,
            child: Transform.rotate(
              angle: -0.65,
              child: Container(width: 32, height: 132, decoration: BoxDecoration(color: const Color(0xFF3FBF50), borderRadius: BorderRadius.circular(20))),
            ),
          ),
          Positioned(
            right: 145,
            bottom: 60,
            child: Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(36),
                boxShadow: const [BoxShadow(color: Color(0x1A000000), blurRadius: 14, offset: Offset(0, 7))],
              ),
              child: const Icon(Icons.check_rounded, color: Color(0xFF2CC95A), size: 48),
            ),
          ),
        ],
      ),
    );
  }
}

class _FoodItem extends StatelessWidget {
  const _FoodItem({required this.color, required this.width, required this.height});
  final Color color;
  final double width;
  final double height;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(26),
        boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 10, offset: Offset(0, 6))],
      ),
    );
  }
}

class _LoginCard extends StatelessWidget {
  const _LoginCard({required this.child, this.topRadiusOnly = false, this.minHeight});
  final Widget child;
  final bool topRadiusOnly;
  final double? minHeight;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      constraints: BoxConstraints(minHeight: minHeight ?? 0),
      padding: const EdgeInsets.fromLTRB(24, 30, 24, 24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: topRadiusOnly
            ? const BorderRadius.vertical(top: Radius.circular(34))
            : const BorderRadius.vertical(top: Radius.circular(34)),
        boxShadow: const [BoxShadow(color: Color(0x08000000), blurRadius: 24, offset: Offset(0, -8))],
      ),
      child: child,
    );
  }
}

class _PrimaryButton extends StatelessWidget {
  const _PrimaryButton({
    required this.label,
    required this.onPressed,
    this.loading = false,
    this.disabledColor,
    this.disabledTextColor,
  });

  final String label;
  final VoidCallback? onPressed;
  final bool loading;
  final Color? disabledColor;
  final Color? disabledTextColor;

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null;
    return SizedBox(
      height: 70,
      child: FilledButton(
        onPressed: onPressed,
        style: FilledButton.styleFrom(
          backgroundColor: enabled ? kPrimaryColor : (disabledColor ?? const Color(0xFFE9ECEF)),
          foregroundColor: enabled ? Colors.white : (disabledTextColor ?? const Color(0xFF8D939A)),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          textStyle: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
        ),
        child: loading
            ? const SizedBox(
                width: 25,
                height: 25,
                child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white),
              )
            : Text(label),
      ),
    );
  }
}

class _OutlineActionButton extends StatelessWidget {
  const _OutlineActionButton({required this.label, required this.onPressed});
  final String label;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 66,
      child: OutlinedButton(
        onPressed: onPressed,
        style: OutlinedButton.styleFrom(
          side: const BorderSide(color: Color(0xFF8A8F95), width: 1.2),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          foregroundColor: const Color(0xFF6B7178),
          textStyle: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
        ),
        child: Text(label),
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.message, required this.onRetry, required this.onHome});

  final String message;
  final VoidCallback onRetry;
  final VoidCallback onHome;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: kPageColor,
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
              boxShadow: const [BoxShadow(color: Color(0x1A000000), blurRadius: 24, offset: Offset(0, 12))],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.wifi_off_rounded, size: 54, color: Color(0xFF0B4A7A)),
                const SizedBox(height: 14),
                const Text('اتصال برقرار نشد', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                const SizedBox(height: 8),
                Text(message, textAlign: TextAlign.center, style: const TextStyle(height: 1.7, color: Color(0xFF4B5563))),
                const SizedBox(height: 18),
                Row(
                  children: [
                    Expanded(child: OutlinedButton.icon(onPressed: onHome, icon: const Icon(Icons.home_rounded), label: const Text('خانه'))),
                    const SizedBox(width: 10),
                    Expanded(child: FilledButton.icon(onPressed: onRetry, icon: const Icon(Icons.refresh_rounded), label: const Text('تلاش مجدد'))),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
