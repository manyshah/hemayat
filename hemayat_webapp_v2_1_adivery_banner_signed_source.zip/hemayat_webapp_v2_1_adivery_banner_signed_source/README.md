# استعلام کالابرگ و یارانه - v2.1

نسخه ساده WebView با تبلیغ بنری Adivery، آیکون انتخابی، پکیج‌نیم `com.manyshah.hemayat` و خروجی signed APK.

## مشخصات
- App name: استعلام کالابرگ و یارانه
- Package: com.manyshah.hemayat
- Version: 1.0.0+1
- WebView URL: https://hemayat.sfara.ir/
- Adivery App ID: c48edfc9-1b2a-4d0c-8076-3c379f107a87
- Banner Placement ID: 7b5fe5be-6767-45c4-8400-35a325cd3d34

> ریپو را Private نگه دارید چون کی‌استور داخل پروژه قرار دارد.
