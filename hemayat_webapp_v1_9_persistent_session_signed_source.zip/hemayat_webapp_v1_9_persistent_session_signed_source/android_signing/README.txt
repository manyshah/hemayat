این پوشه شامل فایل keystore و key.properties است تا Workflow بتواند خروجی signed APK بسازد.

هشدار:
اگر ریپازیتوری GitHub عمومی است، این پوشه نباید عمومی شود. در حالت عمومی، بهتر است keystore و passwordها در GitHub Secrets قرار بگیرند.
