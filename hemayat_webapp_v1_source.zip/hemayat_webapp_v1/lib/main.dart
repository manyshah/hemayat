import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

const String kInitialUrl = 'https://hemayat.sfara.ir/';
const String kAppName = 'سامانه‌یار حمایت';
const Color kPrimaryColor = Color(0xFF0B4A7A);
const Color kAccentColor = Color(0xFF00A884);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: kPrimaryColor,
      statusBarIconBrightness: Brightness.light,
      navigationBarColor: Colors.white,
      navigationBarIconBrightness: Brightness.dark,
    ),
  );
  runApp(const HemayatWebApp());
}

class HemayatWebApp extends StatelessWidget {
  const HemayatWebApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: kAppName,
      debugShowCheckedModeBanner: false,
      locale: const Locale('fa', 'IR'),
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(
          seedColor: kPrimaryColor,
          primary: kPrimaryColor,
          secondary: kAccentColor,
        ),
        scaffoldBackgroundColor: const Color(0xFFF5F7FA),
        appBarTheme: const AppBarTheme(
          backgroundColor: kPrimaryColor,
          foregroundColor: Colors.white,
          centerTitle: true,
          elevation: 0,
          systemOverlayStyle: SystemUiOverlayStyle(
            statusBarColor: kPrimaryColor,
            statusBarIconBrightness: Brightness.light,
          ),
        ),
      ),
      builder: (context, child) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: const WebAppHomePage(),
    );
  }
}

class WebAppHomePage extends StatefulWidget {
  const WebAppHomePage({super.key});

  @override
  State<WebAppHomePage> createState() => _WebAppHomePageState();
}

class _WebAppHomePageState extends State<WebAppHomePage> {
  late final WebViewController _controller;
  int _progress = 0;
  bool _hasMainFrameError = false;
  String _errorText = 'اتصال برقرار نشد. اینترنت را بررسی کنید و دوباره تلاش کنید.';

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.white)
      ..enableZoom(false)
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (progress) {
            if (!mounted) return;
            setState(() => _progress = progress);
          },
          onPageStarted: (_) {
            if (!mounted) return;
            setState(() {
              _hasMainFrameError = false;
              _progress = 0;
            });
          },
          onPageFinished: (_) {
            if (!mounted) return;
            setState(() => _progress = 100);
          },
          onWebResourceError: (error) {
            final isMainFrame = error.isForMainFrame == true;
            if (!mounted || !isMainFrame) return;
            setState(() {
              _hasMainFrameError = true;
              _errorText = error.description.isNotEmpty
                  ? error.description
                  : 'صفحه باز نشد. اینترنت را بررسی کنید.';
            });
          },
          onNavigationRequest: (request) {
            final uri = Uri.tryParse(request.url);
            if (uri == null) return NavigationDecision.navigate;

            final shouldOpenExternally = <String>{
              'tel',
              'mailto',
              'sms',
              'intent',
              'market',
            }.contains(uri.scheme);

            if (shouldOpenExternally) {
              unawaited(_openExternal(uri));
              return NavigationDecision.prevent;
            }
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadRequest(Uri.parse(kInitialUrl));
  }

  Future<void> _openExternal(Uri uri) async {
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      if (!mounted) return;
      _showSnack('امکان باز کردن این لینک وجود ندارد.');
    }
  }

  Future<void> _reload() async {
    setState(() {
      _hasMainFrameError = false;
      _progress = 0;
    });
    await _controller.reload();
  }

  Future<void> _goHome() async {
    setState(() {
      _hasMainFrameError = false;
      _progress = 0;
    });
    await _controller.loadRequest(Uri.parse(kInitialUrl));
  }

  Future<bool> _handleBackNavigation() async {
    if (await _controller.canGoBack()) {
      await _controller.goBack();
      return false;
    }

    if (!mounted) return true;
    final shouldExit = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('خروج از برنامه'),
        content: const Text('می‌خواهید از برنامه خارج شوید؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('خیر'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('خروج'),
          ),
        ],
      ),
    );
    return shouldExit ?? false;
  }

  Future<void> _onPopInvoked(bool didPop, Object? result) async {
    if (didPop) return;
    final shouldExit = await _handleBackNavigation();
    if (shouldExit) {
      await SystemNavigator.pop();
    }
  }

  void _showAboutSheet() {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (context) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              kAppName,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 10),
            const Text(
              'این برنامه برای دسترسی سریع‌تر به سامانه طراحی شده است. اطلاعات ورود، کد تأیید یا داده‌های شخصی کاربران توسط برنامه ذخیره نمی‌شود و ورود فقط از طریق خود سایت انجام می‌شود.',
              style: TextStyle(height: 1.7),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      Navigator.pop(context);
                      _goHome();
                    },
                    icon: const Icon(Icons.home_rounded),
                    label: const Text('صفحه اصلی'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: FilledButton.icon(
                    onPressed: () {
                      Navigator.pop(context);
                      _reload();
                    },
                    icon: const Icon(Icons.refresh_rounded),
                    label: const Text('تازه‌سازی'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showSnack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final showProgress = _progress > 0 && _progress < 100;

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        unawaited(_onPopInvoked(didPop, result));
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            kAppName,
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
          ),
          actions: [
            IconButton(
              tooltip: 'صفحه اصلی',
              onPressed: _goHome,
              icon: const Icon(Icons.home_rounded),
            ),
            IconButton(
              tooltip: 'تازه‌سازی',
              onPressed: _reload,
              icon: const Icon(Icons.refresh_rounded),
            ),
            IconButton(
              tooltip: 'درباره',
              onPressed: _showAboutSheet,
              icon: const Icon(Icons.info_outline_rounded),
            ),
          ],
        ),
        body: Stack(
          children: [
            WebViewWidget(controller: _controller),
            if (_hasMainFrameError)
              _ErrorView(
                message: _errorText,
                onRetry: _reload,
                onHome: _goHome,
              ),
            if (showProgress)
              Align(
                alignment: Alignment.topCenter,
                child: LinearProgressIndicator(
                  value: _progress / 100,
                  minHeight: 3,
                  backgroundColor: Colors.transparent,
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({
    required this.message,
    required this.onRetry,
    required this.onHome,
  });

  final String message;
  final VoidCallback onRetry;
  final VoidCallback onHome;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: double.infinity,
      color: const Color(0xFFF5F7FA),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
              boxShadow: const [
                BoxShadow(
                  blurRadius: 28,
                  offset: Offset(0, 12),
                  color: Color(0x1A000000),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 68,
                  height: 68,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Color(0xFFEAF3F8),
                  ),
                  child: const Icon(
                    Icons.wifi_off_rounded,
                    color: kPrimaryColor,
                    size: 34,
                  ),
                ),
                const SizedBox(height: 18),
                const Text(
                  'صفحه باز نشد',
                  style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 10),
                Text(
                  message,
                  textAlign: TextAlign.center,
                  style: const TextStyle(height: 1.7, color: Color(0xFF4B5563)),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: onHome,
                        icon: const Icon(Icons.home_rounded),
                        label: const Text('خانه'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: onRetry,
                        icon: const Icon(Icons.refresh_rounded),
                        label: const Text('تلاش مجدد'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
