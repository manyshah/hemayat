import 'dart:async';

import 'package:adivery/adivery.dart';
import 'package:adivery/adivery_ads.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

const String kInitialUrl = 'https://hemayat.sfara.ir/';
const String kAppName = 'استعلام کالابرگ و یارانه';
const String kAdiveryAppId = 'c48edfc9-1b2a-4d0c-8076-3c379f107a87';
const String kAdiveryBannerPlacementId = '7b5fe5be-6767-45c4-8400-35a325cd3d34';
const List<String> kAdiveryBannerPlacementIds = <String>[
  kAdiveryBannerPlacementId,
  kAdiveryBannerPlacementId,
  kAdiveryBannerPlacementId,
];
const Color kPrimaryColor = Color(0xFF0B4A7A);
const Color kBackgroundColor = Color(0xFFF4F7FB);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: kPrimaryColor,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Colors.white,
      systemNavigationBarIconBrightness: Brightness.dark,
    ),
  );
  AdiveryPlugin.initialize(kAdiveryAppId);
  AdiveryPlugin.setLoggingEnabled(false);
  runApp(const HemayatApp());
}

class HemayatApp extends StatelessWidget {
  const HemayatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: kAppName,
      debugShowCheckedModeBanner: false,
      locale: const Locale('fa', 'IR'),
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: kPrimaryColor,
          primary: kPrimaryColor,
        ),
        scaffoldBackgroundColor: kBackgroundColor,
        appBarTheme: const AppBarTheme(
          backgroundColor: kPrimaryColor,
          foregroundColor: Colors.white,
          centerTitle: true,
          elevation: 0,
          titleTextStyle: TextStyle(
            color: Colors.white,
            fontSize: 15,
            fontWeight: FontWeight.w800,
          ),
          systemOverlayStyle: SystemUiOverlayStyle(
            statusBarColor: kPrimaryColor,
            statusBarIconBrightness: Brightness.light,
          ),
        ),
      ),
      builder: (context, child) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: const SplashGate(),
    );
  }
}

class SplashGate extends StatefulWidget {
  const SplashGate({super.key});

  @override
  State<SplashGate> createState() => _SplashGateState();
}

class _SplashGateState extends State<SplashGate> {
  bool _showSplash = true;

  @override
  void initState() {
    super.initState();
    Timer(const Duration(milliseconds: 2200), () {
      if (!mounted) return;
      setState(() => _showSplash = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_showSplash) return const SplashScreen();
    return const WebViewScreen();
  }
}

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kPrimaryColor,
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 98,
                height: 98,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x33000000),
                      blurRadius: 26,
                      offset: Offset(0, 12),
                    ),
                  ],
                ),
                child: Image.asset('assets/icon/app_icon.png'),
              ),
              const SizedBox(height: 20),
              const Text(
                kAppName,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'دسترسی سریع به سامانه',
                style: TextStyle(
                  color: Color(0xDFFFFFFF),
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 28),
              const SizedBox(
                width: 28,
                height: 28,
                child: CircularProgressIndicator(
                  strokeWidth: 3,
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class WebViewScreen extends StatefulWidget {
  const WebViewScreen({super.key});

  @override
  State<WebViewScreen> createState() => _WebViewScreenState();
}

class _WebViewScreenState extends State<WebViewScreen> {
  late final WebViewController _controller;
  int _progress = 0;
  bool _hasError = false;
  String _errorMessage = 'اتصال برقرار نشد. اینترنت را بررسی کنید و دوباره تلاش کنید.';

  bool get _isLoading => _progress > 0 && _progress < 100;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.white)
      ..enableZoom(true)
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (progress) {
            if (!mounted) return;
            setState(() => _progress = progress);
          },
          onPageStarted: (_) {
            if (!mounted) return;
            setState(() {
              _hasError = false;
              _progress = 0;
            });
          },
          onPageFinished: (_) {
            if (!mounted) return;
            setState(() => _progress = 100);
          },
          onWebResourceError: (error) {
            if (!mounted || error.isForMainFrame != true) return;
            setState(() {
              _hasError = true;
              _errorMessage = error.description.isNotEmpty
                  ? error.description
                  : 'صفحه باز نشد. اینترنت را بررسی کنید.';
            });
          },
          onNavigationRequest: (request) {
            final uri = Uri.tryParse(request.url);
            if (uri == null) return NavigationDecision.navigate;

            final externalSchemes = <String>{
              'tel',
              'mailto',
              'sms',
              'intent',
              'market',
            };
            if (externalSchemes.contains(uri.scheme)) {
              unawaited(_openExternal(uri));
              return NavigationDecision.prevent;
            }
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadRequest(Uri.parse(kInitialUrl));
  }

  Future<void> _openExternal(Uri uri) async {
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('امکان باز کردن این لینک وجود ندارد.')),
      );
    }
  }

  Future<void> _reload() async {
    setState(() {
      _hasError = false;
      _progress = 0;
    });
    await _controller.reload();
  }

  Future<bool> _handleBack() async {
    if (await _controller.canGoBack()) {
      await _controller.goBack();
      return false;
    }

    final shouldExit = await showDialog<bool>(
      context: context,
      barrierDismissible: true,
      builder: (dialogContext) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(22),
            ),
            title: const Text(
              'خروج از برنامه',
              style: TextStyle(fontWeight: FontWeight.w900),
            ),
            content: const Text(
              'آیا برای خروج از برنامه مطمئن هستید؟',
              style: TextStyle(height: 1.7),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(dialogContext).pop(false),
                child: const Text('خیر'),
              ),
              FilledButton(
                onPressed: () => Navigator.of(dialogContext).pop(true),
                child: const Text('بله، خروج'),
              ),
            ],
          ),
        );
      },
    );

    if (shouldExit == true) {
      await SystemNavigator.pop();
    }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        unawaited(_handleBack());
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text(kAppName),
          actions: [
            IconButton(
              tooltip: 'تازه‌سازی',
              onPressed: _reload,
              icon: const Icon(Icons.refresh_rounded),
            ),
          ],
        ),
        body: Column(
          children: [
            Expanded(
              child: Stack(
                children: [
                  WebViewWidget(controller: _controller),
                  if (_hasError) _ErrorView(message: _errorMessage, onRetry: _reload),
                  if (_isLoading)
                    Align(
                      alignment: Alignment.topCenter,
                      child: LinearProgressIndicator(
                        minHeight: 3,
                        value: _progress / 100,
                        backgroundColor: Colors.transparent,
                      ),
                    ),
                ],
              ),
            ),
            const SafeArea(
              top: false,
              child: _AdiveryBannerBox(),
            ),
          ],
        ),
      ),
    );
  }
}

class _AdiveryBannerBox extends StatefulWidget {
  const _AdiveryBannerBox();

  @override
  State<_AdiveryBannerBox> createState() => _AdiveryBannerBoxState();
}

class _AdiveryBannerBoxState extends State<_AdiveryBannerBox> {
  late final PageController _pageController;
  Timer? _slideTimer;
  int _currentVisiblePage = 0;
  final List<bool> _failed = List<bool>.filled(kAdiveryBannerPlacementIds.length, false);

  List<int> get _visibleIndexes {
    final indexes = <int>[];
    for (var i = 0; i < kAdiveryBannerPlacementIds.length; i++) {
      if (!_failed[i]) indexes.add(i);
    }
    return indexes;
  }

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
    _slideTimer = Timer.periodic(const Duration(seconds: 15), (_) {
      _goToNextAd();
    });
  }

  @override
  void dispose() {
    _slideTimer?.cancel();
    _pageController.dispose();
    super.dispose();
  }

  void _goToNextAd() {
    if (!mounted) return;
    final visible = _visibleIndexes;
    if (visible.length <= 1 || !_pageController.hasClients) return;

    _currentVisiblePage = (_currentVisiblePage + 1) % visible.length;
    _pageController.animateToPage(
      _currentVisiblePage,
      duration: const Duration(milliseconds: 420),
      curve: Curves.easeOutCubic,
    );
  }

  void _onAdLoaded(int index, Ad ad) {
    if (!mounted) return;
    if (_failed[index]) {
      setState(() => _failed[index] = false);
    }
  }

  void _onError(int index, Ad ad, String error) {
    if (!mounted) return;
    setState(() {
      _failed[index] = true;
      final visible = _visibleIndexes;
      if (visible.isEmpty) {
        _currentVisiblePage = 0;
      } else if (_currentVisiblePage >= visible.length) {
        _currentVisiblePage = 0;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final visible = _visibleIndexes;
    if (visible.isEmpty) return const SizedBox.shrink();

    return Container(
      width: double.infinity,
      height: 58,
      alignment: Alignment.center,
      color: Colors.white,
      child: PageView.builder(
        controller: _pageController,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: visible.length,
        onPageChanged: (page) => _currentVisiblePage = page,
        itemBuilder: (context, pageIndex) {
          final adIndex = visible[pageIndex];
          final placementId = kAdiveryBannerPlacementIds[adIndex];
          return Center(
            child: KeyedSubtree(
              key: ValueKey('adivery-banner-$adIndex'),
              child: BannerAd(
                placementId,
                BannerAdSize.BANNER,
                onAdLoaded: (ad) => _onAdLoaded(adIndex, ad),
                onError: (ad, error) => _onError(adIndex, ad, error),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: double.infinity,
      color: kBackgroundColor,
      padding: const EdgeInsets.all(24),
      child: Center(
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(22),
            boxShadow: const [
              BoxShadow(
                color: Color(0x1A000000),
                blurRadius: 24,
                offset: Offset(0, 10),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.wifi_off_rounded, color: kPrimaryColor, size: 44),
              const SizedBox(height: 14),
              const Text(
                'صفحه باز نشد',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 8),
              Text(
                message,
                textAlign: TextAlign.center,
                style: const TextStyle(height: 1.7, color: Color(0xFF4B5563)),
              ),
              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: onRetry,
                  icon: const Icon(Icons.refresh_rounded),
                  label: const Text('تلاش مجدد'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
